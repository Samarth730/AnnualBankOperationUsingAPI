﻿using System.Data;
using System.Data.SqlClient;

namespace BankOperation.DBLAyer
{
    public class DBTransaction
    {
       public string conn = string.Empty;

        public DBTransaction()
        {
            var connectionStr = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("ConnectionStrings")["dbcs"];
            conn = Convert.ToString(connectionStr);
        }

        public DataTable GetDataTable(string query)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection cn =  new SqlConnection();
            SqlDataAdapter ada = new SqlDataAdapter();
            DataTable dt = new DataTable();

           
            cn.ConnectionString = conn;
            cmd.CommandText = query;
            cn.Open();
            cmd.Connection= cn;
            cmd.CommandType = CommandType.Text;
            ada.SelectCommand = cmd;
            ada.Fill(dt);
            cn.Close();
            return dt;
        }


        public int  ExecuteOnlyQuery(string  query)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection cn = new SqlConnection();

            
            cn.ConnectionString = conn;
            cmd.CommandText = query;
            cn.Open();
            cmd.Connection= cn;
            cmd.CommandType = CommandType.Text;
            
            int count = cmd.ExecuteNonQuery();
            cn.Close() ;
            return count;
        }
    }
}
