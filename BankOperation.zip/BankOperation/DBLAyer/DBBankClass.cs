﻿using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace BankOperation.DBLAyer
{
    public class DBBankClass
    {
        string conn = string.Empty;

        public DBBankClass()
        {
            var connstr = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("ConnectionStrings")["dbcs"];
            conn = Convert.ToString(connstr);
        }

        public DataTable GetDataTable(string query)
        {
            SqlCommand sqlCommand = new SqlCommand();
            SqlConnection sqlConnection = new SqlConnection();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dataTable = new DataTable();

            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandText = query;
            sqlConnection.ConnectionString = conn;
            sqlConnection.Open();
            sqlCommand.CommandType = CommandType.Text;
            sqlDataAdapter.SelectCommand = sqlCommand;
            sqlDataAdapter.Fill(dataTable);
           
            sqlConnection.Close();
            return dataTable;

        }

        public int ExecuteOnlyQuery(string query)
        {
            SqlCommand sqlCommand = new SqlCommand();
            SqlConnection sqlConnection = new SqlConnection();

            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandText = query;
            sqlConnection.ConnectionString = conn;
            sqlConnection.Open();
            sqlCommand.CommandType = CommandType.Text;
            int count = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            return count;
        }
    }
}
