﻿using BankOperation.BLLayer;
using BankOperation.Model;
using Microsoft.AspNetCore.Mvc;


namespace BankOperation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankController : ControllerBase
    {
        BankBLClass bl = new BankBLClass();
        [HttpGet]
        [Route("getAllDetailes")]
       public IActionResult getAllDatailes()
        {
            List<BankModelClass> list = new List<BankModelClass>();
            list = bl.getAllDatailes();
            return Ok(list);
        }





        [HttpGet]
        [Route("GetOneDetials")]
        public IActionResult GetOneBankDetalis([FromQuery] int Id)
        {
            BankModelClass Obj = bl.GetsingleDetails(Id);
;
            if (Obj.BANKID == null)
            {
                return BadRequest("Data Not Found");
            }
            return Ok(Obj);
        }

        [HttpPost]
        [Route("InsertData")]
        public IActionResult InsertDetails([FromQuery] BankModelClass Object)
        {
            BankModelClass v= bl.save(Object);
            return Ok(v);
        }


        [HttpPut]
        [Route("Update")]
        public IActionResult UpdateData([FromQuery] BankModelClass Object)
        {
            bool Result = bl.Updatedata(Object);
            if (Result)
            {
                return Ok("Updated Sucessfully");
            }
            return BadRequest(500);
        }



        [HttpDelete]
        [Route("Delete")]
        public IActionResult deletedata([FromQuery] int id)
        {
           bool Result = bl.deletedata(id);
            if (Result)
                return Ok("Data deleted successfully");
            else
                return BadRequest(500);
        }
    }
    

}
