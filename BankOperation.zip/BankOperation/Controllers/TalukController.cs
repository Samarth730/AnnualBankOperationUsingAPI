﻿using BankOperation.BLLayer;
using BankOperation.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BankOperation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TalukController : ControllerBase
    {
        TalukBLClass bl = new TalukBLClass();
        [HttpGet]
        [Route("getAllData")]
        public IActionResult getAllData()
        {
            List<TalukModelClass> l = new List<TalukModelClass>();
            l = bl.getAll();
            return Ok(l);
        }

        [HttpGet]
        [Route("Accesing by id")]
        public IActionResult getsinle([FromQuery] int id)
        {
            TalukModelClass l = new TalukModelClass();
            l = bl.getOne(id);
            return Ok(l);
        }


        [HttpPost]
        [Route("insert")]
        public IActionResult save([FromQuery] TalukModelClass tm)
        {
            TalukModelClass l = bl.insert(tm);
            return Ok(l);
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult updatedata([FromQuery] TalukModelClass ob)
        {
            TalukModelClass l = bl.update(ob);
            return Ok(l);
        }


        [HttpDelete]
        [Route("delet")]
        public IActionResult delet([FromQuery] int id)
        {
            bool l = bl.delete(id);
            if (l)
            {
                return Ok("suc-cessfully deleted");
            }
            else
            {
                return BadRequest(500);
            }
        }
    }

}
