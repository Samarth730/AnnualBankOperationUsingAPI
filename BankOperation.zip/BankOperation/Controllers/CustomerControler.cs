﻿using BankOperation.BLLayer;
using BankOperation.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BankOperation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerControler : ControllerBase
    {
        CustomerBLClass on = new CustomerBLClass();

        [HttpGet]
        [Route("getall")]
        public IActionResult Get()
        {
            List<CustomerModel> lis = new List<CustomerModel>();
            lis = on.getDetails();
            return Ok(lis);
           
        }



        [HttpGet]
        [Route("getone")]
        public IActionResult get(int id)
        {
           CustomerModel obj = on.getone(id);
            return Ok(obj);

        }




        [HttpPost]
        [Route("insert")]
        public IActionResult insert([FromBody] CustomerModel ob)
        {
            CustomerModel save = on.insert(ob);
            return Ok(save);
        }


        [HttpPut]
        [Route("update")]
        public IActionResult update([FromQuery] CustomerModel ob)
        {
            //#region Desimis
            CustomerModel resu = on.update(ob);
            return StatusCode(resu.StatusCode,resu);
            
            //bool resul = on.update(ob);
            //if(resul)
            //{
            //    return Ok("sucssus fully update");
            //}
            //else
            //{
            //    return BadRequest (500);
            //}
        }


        [HttpDelete]
        [Route("delete")]
        public IActionResult delet([FromQuery] int id)
        {
            bool resul = on.delette(id);
            if (resul)
            {
                return Ok("sucssus fully delete");
            }
            else
            {
                return BadRequest(500);
            }
        }

    }
}
