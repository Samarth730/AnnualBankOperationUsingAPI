﻿using BankOperation.BLLayer;
using BankOperation.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BankOperation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchMasterControler : ControllerBase
    {
        BranchBLClass bl = new BranchBLClass(); 
        [HttpGet]
        [Route("GetAll")]
        public IActionResult GetAll()
        {
            List<BankBranchModel> list = new List<BankBranchModel>();
            list = bl.GetAllDetails();
            return Ok(list);
        }

        [HttpGet]
        [Route("GetOne")]
        public IActionResult GetOneDetails([FromQuery] int id)
        {
            BankBranchModel result = bl.GetOneDetails(id);
            if (result.BranchId == null)
            {
                return BadRequest("Data not found");
            }
            return Ok(result); 
        }


        [HttpPost]
        [Route("Save")]
        public IActionResult SaveDetails([FromQuery] BankBranchModel obj)
        {
            BankBranchModel save = bl.SaveDetails(obj);
            return StatusCode(save.StatusCode, save);
            //bool result = bl.SaveDetails(obj);
            //if(result)
            //{
            //    return Ok("sucssusfully inserted");
            //}
            //return BadRequest("not inserted");
        }



        [HttpPut]
        [Route("update")]
        public IActionResult UpdateDetails([FromQuery] BankBranchModel obj)
        {
            BankBranchModel result = bl.Update(obj);
            return StatusCode(result.StatusCode, result);
        }

        [HttpDelete]
        [Route("delete")]
        public IActionResult delette([FromQuery] int id)
        {
            bool result = bl.delette(id);
            if (result)
            {
                return Ok("sucssusfully Detailed");
            }
            return BadRequest("its not present in datatable");
        }





    }
}
