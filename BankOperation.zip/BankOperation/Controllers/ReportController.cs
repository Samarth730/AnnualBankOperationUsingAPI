﻿using BankOperation.BLLayer;
using BankOperation.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BankOperation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        ReportBLClass on = new ReportBLClass();
        [HttpGet]
        [Route("AllBranch")]
        public IActionResult all()
        {
            List<ReportModel> model = on.getAllReport();
            return Ok(model);
        }

        [HttpGet]
        [Route("FeacthDataByLikeOpratereTalukName")]
        public IActionResult Like([FromQuery] string TalukName)
        {
            List<ReportModel> model = on.GetReportTalukNameByUsingLikeOperater(TalukName);
            return Ok(model);
        }
        
        [HttpGet]
        [Route("FeacthDataByLikeOpratereDistrictName")]
        public IActionResult LIke([FromQuery] string DistrictName)
        {
            List<ReportModel> model = on.GetReportDistrictNameByUsingLikeOperater(DistrictName);
            return Ok(model);
        }


        [HttpGet]
        [Route("FeacthDataByLikeOpraterePincode")]
        public IActionResult LIke([FromQuery] int Pincode)
        {
            List<ReportModel> model = on.GetReportPincodeByUsingLikeOperater(Pincode);
            return Ok(model);
        }

        [HttpGet]
        [Route("FeacthDataByLikeOpratereDistrictId")]
        public IActionResult BLIke([FromQuery] int DistrictId)
        {
            List<ReportModel> model = on.GetReportDistrictIdByUsingLikeOperater(DistrictId);
            return Ok(model);
        }

        [HttpGet]
        [Route("FeacthDataByLikeOpratereTalukId")]
        public IActionResult BTLIke([FromQuery] int TalukID)
        {
            List<ReportModel> model = on.GetReportTalukIdByUsingLikeOperater(TalukID);
            return Ok(model);
        }

        [HttpGet]
        [Route("GetbyTalukName")]
        public IActionResult getTaluk()
        {
            List<ReportModel> model = on.GetReportBasedOnTaluk();
            return Ok(model);
        }



        [HttpGet]
        [Route("FetchLeftJoinData")]
        public IActionResult Fetchleftjoindata()
        {
            List<ReportModel> model = on.FetchleftjoindataBasedOntaluk();
            return Ok(model);
        }



        //[HttpGet]
        //[Route("SelectDataWithY")]
        //public IActionResult Like()
        //{
        //    List<ReportModel> model = on.GetReportTalukNameByUsingLikeOperater();
        //    return Ok(model);
        //}

        
    }
}
