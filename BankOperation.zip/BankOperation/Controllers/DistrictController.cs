﻿using BankOperation.BLLayer;
using BankOperation.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BankOperation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DistrictController : ControllerBase
    {
        DistrictBLClass bl = new DistrictBLClass();
        [HttpGet]
        [Route("getAllData")]
        public IActionResult getAllData()
        {
            List<DistrictModelClass> l = new List<DistrictModelClass>();
            l = bl.getAll();
            return Ok(l);
        }

        [HttpGet]
        [Route("Accesing by id")]
        public IActionResult getsinle([FromQuery] int id)
        {
            DistrictModelClass l = new DistrictModelClass();
            l = bl.getOne(id);
            return Ok(l);
        }


        [HttpPost]
        [Route("insert")]
        public IActionResult save([FromQuery] DistrictModelClass tm)
        {
            DistrictModelClass l = bl.insert(tm);
            return Ok(l);
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult updatedata([FromQuery] DistrictModelClass ob)
        {
            DistrictModelClass l = bl.update(ob);
            return Ok(l);
        }


        [HttpDelete]
        [Route("delet")]
        public IActionResult delet([FromQuery] int id)
        {
            bool l = bl.delete(id);
            if (l)
            {
                return Ok("suc-cessfully deleted");
            }
            else
            {
                return BadRequest(500);
            }
        }
    }

}
