﻿using System.ComponentModel.DataAnnotations;

namespace BankOperation.Model
{
    public class BankBranchModel: ModelResponse
    {
        public int BranchId { get; set; }

        [Required(AllowEmptyStrings = false)]
        [MaxLength(20)]

        public string BranchName { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string BA_IFSC { get; set; }
       
        public Adress temAdd { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string  City { get;  set; }
        [Required(AllowEmptyStrings = false)]
        public int BANKID { get; set; }



    }
}
