﻿using System.ComponentModel.DataAnnotations;

namespace BankOperation.Model
{
    public class TransactionModel:ModelResponse
    {
        public int TRANS_ID { get; set; }
        [Required]
        public int CUST_ID { get; set; }
        [Required]
        public int BRANCH_ID { get; set; }
        [Required]
        public decimal AMOUNT { get; set; }
        public DateTime DATEOFTRANSACTION {  get; set; }
        [Required(AllowEmptyStrings =false)]
        [MaxLength(40)]
        public string TRANS_DONEBY { get; set; }
        [Required]
        public DateTime CLEAR_DATE { get; set; }



    }
}
