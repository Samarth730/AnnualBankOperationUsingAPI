﻿using System.ComponentModel.DataAnnotations;

namespace BankOperation.Model
{
    public class DistrictModelClass:ModelResponse
    {
        public int DistrictId { get; set; }
        [Required(AllowEmptyStrings = true)]
        public string DistrictName { get; set;}
    }
}
