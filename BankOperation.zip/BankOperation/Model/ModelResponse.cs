﻿namespace BankOperation.Model
{
    public class ModelResponse
    {
        public bool IsSuccess { get; set; } = false;
        public string? Message { get; set; }
        public int StatusCode { get; set; }
    }
}
