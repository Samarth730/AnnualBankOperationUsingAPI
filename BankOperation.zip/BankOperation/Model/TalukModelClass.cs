﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace BankOperation.Model
{
    public class TalukModelClass:ModelResponse
    {
        public int Id { get; set; }
        [Required(AllowEmptyStrings = true)]
        [MaxLength(20)]
        public string TalukName { get; set; }
       

        public int DistrictId { get; set; }



    }
}
