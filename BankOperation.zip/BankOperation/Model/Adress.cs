﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace BankOperation.Model
{
    public class Adress
    {
        [Required(AllowEmptyStrings =false)]
        public string temp_place { get; set; }

        public string tempAREA {  get; set; }
        public string tempSTREET { get; set; }

        [Required(ErrorMessage = "Pincode is required")]
        [RegularExpression(@"^\d{6}$", ErrorMessage = "Pincode must be a 6-digit number")]
        

        public int tempPINCODE { get; set; }
        [Required]
        public int tempTALUKID { get; set; }
        [Required]
        public int tempDISTRICTID { get; set; }
        
        public string TempLandmark { get; set; }
        


    }
}
