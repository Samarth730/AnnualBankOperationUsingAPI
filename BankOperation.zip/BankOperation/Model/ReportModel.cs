﻿using System.ComponentModel.DataAnnotations;

namespace BankOperation.Model
{
    public class ReportModel
    {
        [Required]
        public string BranchName { get; set; }


        [Required]
        public string BA_IFSC { get; set; }

        [Required]
        public string Area { get; set; }

        [Required]
        public int Pincode { get; set; }

        [Required]
        public string Street { get; set; }

        [Required]
        public string TalukName { get; set; }

        [Required]
        public string DistrictName { get; set; }
    }
}
