﻿using System.ComponentModel.DataAnnotations;
using System.Net;

namespace BankOperation.Model
{
    public class CustomerModel: ModelResponse
    {
        public int CustID { get; set; }

        [Required(ErrorMessage = "First name is required")]
        [MaxLength(20, ErrorMessage = "First name cannot exceed 20 characters")]
        public string FIRST_NAME { get; set; }

        public string MIDDLE_NAME { get; set; }

        [Required(ErrorMessage = "Last name is required")]
        [MaxLength(5, ErrorMessage = "Last name cannot exceed 5 characters")]
        public string LAST_NAME { get; set; }

        [Required(ErrorMessage = "Father's name is required")]
        [MaxLength(20, ErrorMessage = "Father's name cannot exceed 20 characters")]
        public string FATHER_NAME { get; set; }

        [Required(ErrorMessage = "Mother's name is required")]
        [MaxLength(20, ErrorMessage = "Mother's name cannot exceed 20 characters")]
        public string MotherName { get; set; }

        [Required(ErrorMessage = "Date of birth is required")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        [Range(0, 2, ErrorMessage = "Gender must be 0, 1, or 2")]
        public int GENDER { get; set; }

        public Adress TempAdd { get; set; }

        [Required(ErrorMessage = "Place is required")]
        [MaxLength(50, ErrorMessage = "Place cannot exceed 50 characters")]
        public string PAR_plase { get; set; }

        [Required(ErrorMessage = "Area is required")]
        [MaxLength(50, ErrorMessage = "Area cannot exceed 50 characters")]
        public string PAR_AREA { get; set; }

        [Required(ErrorMessage = "Street is required")]
        [MaxLength(50, ErrorMessage = "Street cannot exceed 50 characters")]
        public string PAR_STREET { get; set; }

        [Required(ErrorMessage = "PIN code is required")]
        [RegularExpression(@"^\d{6}$", ErrorMessage = "Invalid PIN code")]
        public int PAR_PINCODE { get; set; }

        [Required(ErrorMessage = "Taluk ID is required")]
        public int PAR_TALUK_ID { get; set; }

        [Required(ErrorMessage = "District ID is required")]
        public int PAR_DISTRICT_ID { get; set; }

        [Required(ErrorMessage = "Landmark is required")]
        [MaxLength(50, ErrorMessage = "Landmark cannot exceed 50 characters")]
        public string PAR_LANDMARK { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        [MaxLength(10, ErrorMessage = "Mobile number cannot exceed 10 characters")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Invalid mobile number")]
        public string MOBILE_NUMBER { get; set; }

        [Required(ErrorMessage = "Aadhar number is required")]
        [MaxLength(12, ErrorMessage = "Aadhar number cannot exceed 12 characters")]
        [RegularExpression(@"^\d{12}$", ErrorMessage = "Invalid Aadhar number")]
        public string AADHAR_NUMBER { get; set; }

        [Required(ErrorMessage = "PAN number is required")]
        [MaxLength(10, ErrorMessage = "PAN number cannot exceed 10 characters")]
        [RegularExpression(@"^([A-Z]){5}([0-9]){4}([A-Z]){1}$", ErrorMessage = "Invalid PAN number")]
        public string PAN_NUMBER { get; set; }

        [Required(ErrorMessage = "Email address is required")]
        [MaxLength(100, ErrorMessage = "Email address cannot exceed 100 characters")]
        [RegularExpression(@"^[^\s@]+@[^\s@]+\.[^\s@]+$", ErrorMessage = "Invalid Email Address")]
        public string EMAIL_ID { get; set; }


    }
}
