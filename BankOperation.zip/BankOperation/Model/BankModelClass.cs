﻿using System.ComponentModel.DataAnnotations;

namespace BankOperation.Model
{
    public class BankModelClass:ModelResponse
    {
        public int BANKID { get; set; }

        [Required(AllowEmptyStrings = false)]
        [MaxLength(30)]
        public string BA_NAME { get; set; }
        
       
      

        public int TOTALNOOFBRANCH { get; set; }

    }
}
