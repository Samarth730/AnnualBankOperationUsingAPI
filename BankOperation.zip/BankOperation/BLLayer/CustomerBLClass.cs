﻿using BankOperation.DBLAyer;
using BankOperation.Model;
using System.Data;
using System.Reflection;
using System.Text.RegularExpressions;

namespace BankOperation.BLLayer
{
    public class CustomerBLClass
    {
        string query = string.Empty;
        DBCustomer db = new DBCustomer();
        CustomerModel ob = new CustomerModel();
        public List<CustomerModel> getDetails()
        {
            List<CustomerModel> l1 = new List<CustomerModel>();
            query = "select * from [Customer]";
            DataTable d = db.GetDataTable(query);
            l1 = GetAllDetails(d);
            return l1;

        }

        public CustomerModel getone(int id)
        {
           CustomerModel l1 = new CustomerModel();
            query = "select * from [Customer] where Id="+id+"";
            DataTable d = db.GetDataTable(query);
            l1 = GetAllDetails(d).FirstOrDefault();
            return l1;

        }
        

        public CustomerModel insert(CustomerModel m)
        {
            DistrictBLClass bld = new DistrictBLClass();
            DistrictModelClass bod = new DistrictModelClass();
            string regExpresion = @"[A-Z]{5}[0-9]{4}[A-Z]{1}";
            if(m.DOB >= DateTime.Today)
            {
                m.IsSuccess = false;
                m.Message = "Data of Birth is invalid "+  m.DOB  ;
                m.StatusCode = 404;
                return m;
            }

            #region Validation block

            TalukModelClass talukPropertyObj1 = new TalukBLClass().getOne(m.TempAdd.tempTALUKID);
            TalukModelClass talukPropertyObj2 = new TalukBLClass().getOne(m.PAR_TALUK_ID);

            if (talukPropertyObj1 == null || talukPropertyObj2 == null)
            {
                m.IsSuccess = false;
                m.Message = $"Invalid TalukID {m.TempAdd.tempTALUKID}";
                m.StatusCode = StatusCodes.Status404NotFound;
                return m;
            }
            DistrictModelClass districtPropertyObj1 = new DistrictBLClass().getOne(m.TempAdd.tempDISTRICTID);
            DistrictModelClass districtPropertyObj2 = new DistrictBLClass().getOne(m.PAR_DISTRICT_ID);

            if (districtPropertyObj1 == null || districtPropertyObj2 == null)
            {
                m.IsSuccess = false;
                m.Message = $"Invalid DistrictID {m.TempAdd.tempDISTRICTID}";
                m.StatusCode = StatusCodes.Status404NotFound;
                return m;
            }
            if ((m.TempAdd.tempDISTRICTID != talukPropertyObj1.DistrictId) || m.PAR_DISTRICT_ID != talukPropertyObj2.DistrictId)
            {
                m.IsSuccess = false;
                m.Message = $"Invalid DistrictID {m.TempAdd.tempDISTRICTID}";
                m.StatusCode = StatusCodes.Status404NotFound;
                return m;
            }

            #endregion



            string query = "INSERT INTO Customer VALUES ('" + m.FIRST_NAME + "','" + m.MIDDLE_NAME + "','" + m.LAST_NAME + "','" + m.FATHER_NAME + "','" + m.MotherName + "', CONVERT(date, '" + m.DOB.ToString("yyyy-MM-dd") + "'),'" + m.TempAdd.temp_place + "','" + m.TempAdd.tempAREA + "','" + m.TempAdd.tempSTREET + "'," + m.TempAdd.tempPINCODE + "," + m.TempAdd.tempTALUKID + "," + m.TempAdd.tempDISTRICTID + ",'" + m.TempAdd.TempLandmark + "','" + m.PAR_plase + "','" + m.PAR_AREA + "','" + m.PAR_STREET + "'," + m.PAR_PINCODE + "," + m.PAR_TALUK_ID + "," + m.PAR_DISTRICT_ID + ",'" + m.PAR_LANDMARK + "'," + m.GENDER + "," + m.MOBILE_NUMBER + ",'" + m.AADHAR_NUMBER + "','" + m.PAN_NUMBER + "','" + m.EMAIL_ID + "')";


            int count = db.ExecuteOnlyQuery(query);
            if (count > 0)
            {
                m.IsSuccess = true;
                m.Message = "successfully";
                m.StatusCode = 200;
                return m;
            }
            else
            {
                m.IsSuccess = false;
                m.Message = "dasas unsuccessfully";
                m.StatusCode = 500;
                return m;
            }
            return m;


        }


        public CustomerModel update(CustomerModel Obj)
        {
            #region Validation block

            TalukModelClass talukPropertyObj1 = new TalukBLClass().getOne(Obj.TempAdd.tempTALUKID);
            TalukModelClass talukPropertyObj2 = new TalukBLClass().getOne(Obj.PAR_TALUK_ID);

            if (talukPropertyObj1 == null || talukPropertyObj2 == null)
            {
                Obj.IsSuccess = false;
                Obj.Message = $"Invalid TalukID {Obj.TempAdd.tempTALUKID}";
                Obj.StatusCode = StatusCodes.Status404NotFound;
                return Obj;
            }
            DistrictModelClass districtPropertyObj1 = new DistrictBLClass().getOne(Obj.TempAdd.tempDISTRICTID);
            DistrictModelClass districtPropertyObj2 = new DistrictBLClass().getOne(Obj.PAR_DISTRICT_ID);

            if (districtPropertyObj1 == null || districtPropertyObj2 == null)
            {
                Obj.IsSuccess = false;
                Obj.Message = $"Invalid DistrictID {Obj.TempAdd.tempDISTRICTID}";
                Obj.StatusCode = StatusCodes.Status404NotFound;
                return Obj;
            }
            if ((Obj.TempAdd.tempDISTRICTID != talukPropertyObj1.DistrictId) || Obj.PAR_DISTRICT_ID != talukPropertyObj2.DistrictId)
            {
                Obj.IsSuccess = false;
                Obj.Message = $"Invalid DistrictID {Obj.TempAdd.tempDISTRICTID}";
                Obj.StatusCode = StatusCodes.Status404NotFound;
                return Obj;
            }

            #endregion
            query = "UPDATE Customer SET [FirstName] = '" + Obj.FIRST_NAME + "', " +
                           "" + "[MiddleName] = '" + Obj.MIDDLE_NAME +
                                   "', [LastName] = '" + Obj.LAST_NAME +
                                   "', [FatherName] = '" + Obj.FATHER_NAME +
                                   "', MotherName = '" + Obj.MotherName +
                                   "', [DOB] = '" + Obj.DOB + // Assuming DOB is of DATE type
                                   "', [Gender] = " + Obj.GENDER +
                                   ", [TempPlace] = '" + Obj.TempAdd.temp_place +
                                   "', [TempArea] = '" + Obj.TempAdd.tempSTREET +
                                   "', [TempStreet] = " + Obj.TempAdd.tempPINCODE +
                                   ", [TempPincode] = " + Obj.TempAdd.tempTALUKID +
                                   ", [TempDistrictID] = " + Obj.TempAdd.tempDISTRICTID +
                                   ", [TempLandmark] = '" + Obj.TempAdd.TempLandmark +
                                   "', [PermanentPlace] =' " + Obj.PAR_plase +
                                   "', [PermanentArea] = '" + Obj.PAR_AREA +
                                   "', [PermanentStreet] = '" + Obj.PAR_STREET +
                                   "', [PermanentPincode] = " + Obj.PAR_PINCODE +
                                   ", [PermanentTalukID] = " + Obj.PAR_TALUK_ID +
                                   ", [PermanentDistrictID] = " + Obj.PAR_DISTRICT_ID +
                                   ", [PermanentLandmark] = '" + Obj.PAR_LANDMARK +
                                   "', [MobileNumber] = '" + Obj.MOBILE_NUMBER +
                                   "', [AadharNumber] = '" + Obj.AADHAR_NUMBER +
                                   "', [PanNumber] = '" + Obj.PAN_NUMBER +
                                   "', [EmailID] = '" + Obj.EMAIL_ID +
                                   "' WHERE Id = " + Obj.CustID;

            int count = db.ExecuteOnlyQuery(query);
            if (count > 0)
            {
                Obj.IsSuccess = true;
                Obj.Message = "successfully";
                Obj.StatusCode = 200;
                return Obj;
            }
            else
            {
                Obj.IsSuccess = false;
                Obj.Message = "dasas unsuccessfully";
                Obj.StatusCode = 500;
                return Obj;
            }
            //return l1;


        }


        public bool delette(int id)
        {
            query = "delete from Customer where  [Id]=" + id + "";
            int resuly = db.ExecuteOnlyQuery(query);
            if (resuly > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }




        private List<CustomerModel> GetAllDetails(DataTable tabl)
        {
            List<CustomerModel> l1 = new List<CustomerModel>();
            for (int i = 0; i < tabl.Rows.Count; i++)
            {
                CustomerModel ob = new CustomerModel();
                ob.CustID = (int)tabl.Rows[i]["Id"];
                ob.FIRST_NAME = (string)tabl.Rows[i]["FirstName"];
                ob.LAST_NAME = (string)tabl.Rows[i]["LastName"];

                ob.MIDDLE_NAME = (string)tabl.Rows[i]["MiddleName"];
                ob.FATHER_NAME = (string)tabl.Rows[i]["FatherName"];
                ob.MotherName = (string)tabl.Rows[i]["MotherName"];
                ob.DOB = (DateTime)tabl.Rows[i]["DOB"];
                Adress add = new Adress();
                {
                    add.temp_place = (string)tabl.Rows[i]["TempPlace"];
                    add.tempAREA = (string)tabl.Rows[i]["TempArea"];
                    add.tempSTREET = (string)tabl.Rows[i]["TempStreet"];
                    add.tempPINCODE = (int)tabl.Rows[i]["TempPincode"];
                    add.tempTALUKID = (int)tabl.Rows[i]["TempTalukID"];
                    add.tempDISTRICTID = (int)tabl.Rows[i]["TempDistrictID"];
                    add.TempLandmark = (string)tabl.Rows[i]["TempLandmark"];

                }
                ob.TempAdd = add;
                ob.PAR_plase = (string)tabl.Rows[i]["PermanentPlace"];
                ob.PAR_AREA = (string)tabl.Rows[i]["PermanentArea"];
                ob.PAR_STREET = (string)tabl.Rows[i]["PermanentStreet"];
                ob.PAR_PINCODE = (int)tabl.Rows[i]["PermanentPincode"];
                ob.PAR_TALUK_ID = (int)tabl.Rows[i]["PermanentTalukID"];
                ob.PAR_DISTRICT_ID = (int)tabl.Rows[i]["PermanentDistrictID"];
                ob.PAR_LANDMARK = (string)tabl.Rows[i]["PermanentLandmark"];
                ob.GENDER = (int)tabl.Rows[i]["Gender"];
                ob.MOBILE_NUMBER = (string)tabl.Rows[i]["MobileNumber"];
                ob.AADHAR_NUMBER = (string)tabl.Rows[i]["AadharNumber"];
                ob.PAN_NUMBER = (string)tabl.Rows[i]["PanNumber"];
                ob.EMAIL_ID = (string)tabl.Rows[i]["EmailID"];
                l1.Add(ob);
            }
            return l1;


        }
    }
    
    
}
