﻿using BankOperation.DBLAyer;
using BankOperation.Model;
using System.Data;

namespace BankOperation.BLLayer
{
    public class ReportBLClass
    {
        ReportModel model = new ReportModel();
        DBCustomer db = new DBCustomer();
        string query = string.Empty;

        public List<ReportModel> getAllReport()
        {
            List<ReportModel> lstrep = new List<ReportModel>();

            string query = "SELECT bm.BranchName AS [Branch Name], " +
                       "bm.BA_IFSC AS [Branch IFSC], " +
                       "bm.Area AS [Branch Area], " +
                       "bm.Street AS [Branch Street], " +
                       "bm.Pincode AS [Branch Pincode], " +
                       "tm.TalukName AS [Taluk Name], " +
                       "dm.DistrictName AS [District Name] " +
                       "FROM BranchMaster bm " +
                       "INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID " +
                       "INNER JOIN DistrictMaster1 dm ON dm.DistrictId = bm.DistrictId";

            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }
        public List<ReportModel> GetReportBasedOnTaluk()
        {
            List<ReportModel> lstrep = new List<ReportModel>();

            string query = "SELECT bm.BranchName AS [Branch Name], " +
                       "bm.BA_IFSC AS [Branch IFSC], " +
                       "bm.Area AS [Branch Area], " +
                       "bm.Street AS [Branch Street], " +
                       "bm.Pincode AS [Branch Pincode], " +
                       "tm.TalukName AS [Taluk Name], " +
                       "dm.DistrictName AS [District Name] " +
                       "FROM BranchMaster bm " +
                       "INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID " +
                       "INNER JOIN DistrictMaster1 dm ON dm.DistrictId = bm.DistrictId ORDER BY tm.TalukName";

            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }
        public List<ReportModel> GetReportBasedOnDistrictName()
        {
            List<ReportModel> lstrep = new List<ReportModel>();

                  string query = @"
          SELECT bm.BranchName AS [Branch Name],
                 bm.BA_IFSC AS [Branch IFSC],
                 bm.Area AS [Branch Area],
                 bm.Street AS [Branch Street],
                 bm.Pincode AS [Branch Pincode],
                 tm.TalukName AS [Taluk Name],
                 dm.DistrictName AS [District Name]
          FROM BranchMaster bm
          INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID
          INNER JOIN DistrictMaster1 dm ON dm.DistrictId = bm.DistrictId
          ORDER BY dm.DistrictName DESC;
";

            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }
        public List<ReportModel> GetReportTalukNameByUsingLikeOperater(string TalukName)
        {
            List<ReportModel> lstrep = new List<ReportModel>();
              string query = "SELECT bm.BranchName AS [Branch Name], bm.BA_IFSC AS [Branch IFSC], bm.Area AS [Branch Area],bm.Street AS [Branch Street], bm.Pincode AS [Branch Pincode], tm.TalukName AS [Taluk Name],dm.DistrictName AS [District Name] FROM BranchMaster bm INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID INNER JOIN DistrictMaster1 dm ON dm.DistrictId = tm.DistrictId WHERE tm.TalukName LIKE '%" + TalukName + "%'";
             DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }
        public List<ReportModel> GetReportDistrictNameByUsingLikeOperater(string DistrictName)
        {
            List<ReportModel> lstrep = new List<ReportModel>();
            string query = "SELECT bm.BranchName AS [Branch Name], bm.BA_IFSC AS [Branch IFSC], bm.Area AS [Branch Area], " +
                "bm.Street AS [Branch Street], bm.Pincode AS [Branch Pincode], tm.TalukName AS [Taluk Name], " +
                "dm.DistrictName AS [District Name] " +
                "FROM BranchMaster bm " +
                "INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID " +
                "INNER JOIN DistrictMaster1 dm ON dm.DistrictId = tm.DistrictId " +
                "WHERE dm.DistrictName LIKE '%" + DistrictName + "%'";




            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }

        public List<ReportModel> GetReportDistrictIdByUsingLikeOperater(int DistrictId)
        {
            List<ReportModel> lstrep = new List<ReportModel>();
            string query = "SELECT bm.BranchName AS [Branch Name], bm.BA_IFSC AS [Branch IFSC],bm.DistrictId AS[District Id], bm.Area AS [Branch Area], " +
                "bm.Street AS [Branch Street], bm.Pincode AS [Branch Pincode], tm.TalukName AS [Taluk Name], " +
                "dm.DistrictName AS [District Name] " +
                "FROM BranchMaster bm " +
                "INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID " +
                "INNER JOIN DistrictMaster1 dm ON dm.DistrictId = tm.DistrictId " +
                "WHERE dm.DistrictId LIKE '%" + DistrictId + "%'";




            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }

        public List<ReportModel> GetReportTalukIdByUsingLikeOperater(int TalukID)
        {
            List<ReportModel> lstrep = new List<ReportModel>();
            string query = "SELECT bm.BranchName AS [Branch Name], bm.BA_IFSC AS [Branch IFSC],bm.TalukID AS[Taluk Id], bm.Area AS [Branch Area], " +
                "bm.Street AS [Branch Street], bm.Pincode AS [Branch Pincode], tm.TalukName AS [Taluk Name], " +
                "dm.DistrictName AS [District Name] " +
                "FROM BranchMaster bm " +
                "INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID " +
                "INNER JOIN DistrictMaster1 dm ON dm.DistrictId = tm.DistrictId " +
                "WHERE bm.TalukID LIKE '%" + TalukID + "%'";




            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }


        public List<ReportModel> GetReportPincodeByUsingLikeOperater(int Pincode)
        {
            List<ReportModel> lstrep = new List<ReportModel>();
            string query = "SELECT bm.BranchName AS [Branch Name], bm.BA_IFSC AS [Branch IFSC], bm.Area AS [Branch Area], " +
                "bm.Street AS [Branch Street], bm.Pincode AS [Branch Pincode], tm.TalukName AS [Taluk Name], " +
                "dm.DistrictName AS [District Name] " +
                "FROM BranchMaster bm " +
                "INNER JOIN TalukMaster tm ON tm.Id = bm.TalukID " +
                "INNER JOIN DistrictMaster1 dm ON dm.DistrictId = tm.DistrictId " +
                "WHERE bm.Pincode LIKE '%" + Pincode + "%'";




            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }

        public List<ReportModel> FetchleftjoindataBasedOntaluk()
        {
            List<ReportModel> lstrep = new List<ReportModel>();

            string query = "SELECT bm.BranchName AS [Branch Name], " +
                       "bm.BA_IFSC AS [Branch IFSC], " +
                       "bm.Area AS [Branch Area], " +
                       "bm.Street AS [Branch Street], " +
                       "bm.Pincode AS [Branch Pincode], " +
                       "tm.TalukName AS [Taluk Name], " +
                       "dm.DistrictName AS [District Name] " +
                       "FROM BranchMaster bm " +
                       "LEFT JOIN TalukMaster tm ON tm.Id = bm.TalukID " +
                       "LEFT JOIN DistrictMaster1 dm ON dm.DistrictId = bm.DistrictId ORDER BY tm.TalukName";

            DataTable dt = db.GetDataTable(query);
            lstrep = GetAllReport(dt);
            return lstrep;

        }

        private List<ReportModel> GetAllReport(DataTable tbl)
        {
            List<ReportModel> list = new List<ReportModel>();
            for(int i = 0; i < tbl.Rows.Count; i++)
            {
                ReportModel reob = new ReportModel();
                reob.BranchName = (string)tbl.Rows[i]["Branch Name"];
                reob.BA_IFSC= (string)tbl.Rows[i]["Branch IFSC"];
                reob.Area = (string)tbl.Rows[i]["Branch Area"];
                reob.Pincode = (int)tbl.Rows[i]["Branch Pincode"];
                reob.Street = (string)tbl.Rows[i]["Branch Street"];
                reob.TalukName = (string)tbl.Rows[i]["Taluk Name"];
                reob.DistrictName = (string)tbl.Rows[i]["District Name"];
                list.Add(reob);

            }
            return list;
        }
    }
}
