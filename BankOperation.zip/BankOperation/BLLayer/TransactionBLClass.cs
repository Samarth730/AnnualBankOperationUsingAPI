﻿using BankOperation.DBLAyer;
using BankOperation.Model;
using System.Data;
using System.Data.Common;

namespace BankOperation.BLLayer
{
    public class TransactionBLClass
    {
        //#region Declaretion
        public string query = string.Empty;
        TransactionModel m = new TransactionModel();
        DBTransaction db = new DBTransaction();

        public List<TransactionModel> getdata()
        {
            List<TransactionModel> l = new List<TransactionModel>();
            query = "select * from TransactionMaster1";
            DataTable d = db.GetDataTable(query);
            l= getAllDetails(d);
            return l;
        }

        public TransactionModel getOne(int id)
        {
            TransactionModel ob = new TransactionModel();
            query = "select * from TransactionMaster1 where TRANS_ID =" + id + " ";
            DataTable d = db.GetDataTable(query);
            ob=getAllDetails(d).FirstOrDefault();
            
            if(ob == null)
            {
                ob = new TransactionModel();
                ob.IsSuccess = false;
                ob.Message = "data not found";
                ob.StatusCode = StatusCodes.Status404NotFound;
                return ob;
            }
            return ob;

        }

        public TransactionModel insert(TransactionModel ob)
        {
            #region Validation Code

            //BranchProperties branchProperties = new BranchProperties();
            //BLBranchMaster bLBranchMaster = new BLBranchMaster();

            //branchProperties = bLBranchMaster.GetSingleBranchDetails(transactionObj.BranchID);

            BankBranchModel branchProperties = new BranchBLClass().GetOneDetails(ob.BRANCH_ID);
            if (branchProperties == null)
            {
                ob.IsSuccess = false;
                ob.Message = "Invalid BranchID!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;

            }
            /*CustomerProperties customerProperties = new CustomerProperties();
            BLCustomer bLCustomer = new BLCustomer();

            customerProperties = bLCustomer.GetOnlyOneCustomerDetail(transactionObj.CustomerId);*/

            CustomerModel customerProperties = new CustomerBLClass().getone(ob.CUST_ID);


            if (customerProperties == null)
            {
                ob.IsSuccess = false;
                ob.Message = "Invalid CustomerID!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if (ob.AMOUNT < 100000)
            {
                ob.IsSuccess = false;
                ob.Message = "Amount not in range!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if ((ob.DATEOFTRANSACTION> DateTime.Now) || (ob.DATEOFTRANSACTION <= new DateTime(2023, 3, 31)))
            {
                ob.IsSuccess = false;
                ob.Message = "Transaction date Invalid!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if (ob.TRANS_DONEBY == null)
            {
                ob.IsSuccess = false;
                ob.Message = "TransactionDoneBy is required!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if ((ob.CLEAR_DATE < ob.DATEOFTRANSACTION) || (ob.CLEAR_DATE > DateTime.Now))
            {
                ob.IsSuccess = false;
                ob.Message = "TransactionDoneBy is required!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            #endregion

            query = "Insert into TransactionMaster1 values (" + ob.CUST_ID + "," + ob.BRANCH_ID + "," + ob.AMOUNT + ",'" + ob.DATEOFTRANSACTION + "','" + ob.TRANS_DONEBY + "','" + ob.CLEAR_DATE + "')";
            int a = db.ExecuteOnlyQuery(query);
            if(a>0)
            {
                ob.IsSuccess = true;
                ob.Message = "success";
                ob.StatusCode = StatusCodes.Status200OK;
                return ob;
            }
            else
            {
                ob.IsSuccess = false;
                ob.Message = "no";
                ob.StatusCode = StatusCodes.Status404NotFound;
                return ob;
            }
        }




        public TransactionModel update(TransactionModel ob)
        {

            #region Validation Code

            //BranchProperties branchProperties = new BranchProperties();
            //BLBranchMaster bLBranchMaster = new BLBranchMaster();

            //branchProperties = bLBranchMaster.GetSingleBranchDetails(transactionObj.BranchID);

            BankBranchModel branchProperties = new BranchBLClass().GetOneDetails(ob.BRANCH_ID);
            if (branchProperties == null)
            {
                ob.IsSuccess = false;
                ob.Message = "Invalid BranchID!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;

            }
            /*CustomerProperties customerProperties = new CustomerProperties();
            BLCustomer bLCustomer = new BLCustomer();

            customerProperties = bLCustomer.GetOnlyOneCustomerDetail(transactionObj.CustomerId);*/

            CustomerModel customerProperties = new CustomerBLClass().getone(ob.CUST_ID);


            if (customerProperties == null)
            {
                ob.IsSuccess = false;
                ob.Message = "Invalid CustomerID!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if (ob.AMOUNT < 100000)
            {
                ob.IsSuccess = false;
                ob.Message = "Amount not in range!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if ((ob.DATEOFTRANSACTION > DateTime.Now) || (ob.DATEOFTRANSACTION <= new DateTime(2023, 3, 31)))
            {
                ob.IsSuccess = false;
                ob.Message = "Transaction date Invalid!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if (ob.TRANS_DONEBY == null)
            {
                ob.IsSuccess = false;
                ob.Message = "TransactionDoneBy is required!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            if ((ob.CLEAR_DATE < ob.DATEOFTRANSACTION) || (ob.CLEAR_DATE > DateTime.Now))
            {
                ob.IsSuccess = false;
                ob.Message = "TransactionDoneBy is required!";
                ob.StatusCode = StatusCodes.Status202Accepted;
                return ob;
            }
            #endregion
            query = "update TransactionMaster1 set CUST_ID=" + ob.CUST_ID + ",BRANCH_ID=" + ob.BRANCH_ID + ",AMOUNT=" + ob.AMOUNT + ",DATEOFTRANSACTION='" + ob.DATEOFTRANSACTION + "',TRANS_DONEBY='" + ob.TRANS_DONEBY + "',CLEAR_DATE='" + ob.CLEAR_DATE + "' where TRANS_ID=" + ob.TRANS_ID + " ";
            int a = db.ExecuteOnlyQuery(query);
            if (a > 0)
            {
                ob.IsSuccess = true;
                ob.Message = "success";
                ob.StatusCode = StatusCodes.Status200OK;
                return ob;
            }
            else
            {
                ob.IsSuccess = false;
                ob.Message = "no";
                ob.StatusCode = StatusCodes.Status404NotFound;
                return ob;
            }
        }

        public bool deletr(int id)
        {


            query = "delete from TransactionMaster1  where TRANS_ID=" + id + " ";
            int a = db.ExecuteOnlyQuery(query);
            if (a > 0)
            {
                return true;

            }
            else
                return false;
            
        }


        private List<TransactionModel> getAllDetails(DataTable tbl) 
        {
            List<TransactionModel> l1 = new List<TransactionModel>();
            for(int i=0;i<tbl.Rows.Count;i++)
            {
                TransactionModel tm = new TransactionModel();
                tm.TRANS_ID = (int)tbl.Rows[i]["TRANS_ID"];
                tm.CUST_ID = (int)tbl.Rows[i]["CUST_ID"];
                tm.BRANCH_ID = (int)tbl.Rows[i]["BRANCH_ID"];
                tm.AMOUNT = (decimal)tbl.Rows[i]["AMOUNT"];
                tm.DATEOFTRANSACTION = (DateTime)tbl.Rows[i]["DATEOFTRANSACTION"];
                tm.TRANS_DONEBY = (string)tbl.Rows[i]["TRANS_DONEBY"];
                tm.CLEAR_DATE = (DateTime)tbl.Rows[i]["CLEAR_DATE"];
                tm.IsSuccess = true;
                tm.Message = "sucssuc";
                tm.StatusCode = StatusCodes.Status200OK;
                l1.Add(tm);

            }
            return l1;
        }

    }
}
