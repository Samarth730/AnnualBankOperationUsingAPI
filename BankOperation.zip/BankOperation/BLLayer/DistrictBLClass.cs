﻿using BankOperation.DBLAyer;
using BankOperation.Model;
using System.Data;

namespace BankOperation.BLLayer
{
    public class DistrictBLClass
    {
        DistrictModelClass obj = new DistrictModelClass();
        DBCustomer db = new DBCustomer();
        string query = string.Empty;

        public List<DistrictModelClass> getAll()
        {

            query = "select * from DistrictMaster1";
            DataTable dt = db.GetDataTable(query);
            List<DistrictModelClass> li = getAllDetails(dt);
            return li;

        }

        public DistrictModelClass getOne(int id)
        {
            query = "select * from DistrictMaster1 where DistrictId = " + id + " ";
            DataTable dt = db.GetDataTable(query);
            DistrictModelClass li = getAllDetails(dt).FirstOrDefault();

            if (li == null)
            {
                li = new DistrictModelClass();
                li.IsSuccess = false;
                li.Message = "data is not found ";
                li.StatusCode = 404;
            }
            return li;

        }
        public DistrictModelClass insert(DistrictModelClass o)
        {

            query = "insert into DistrictMaster1 values ('" + o.DistrictName + "')";
            int resut = db.ExecuteOnlyQuery(query);
            if (resut > 0)
            {

                o.IsSuccess = true;
                o.Message = "data inserted suc-cessfully ";
                o.StatusCode = 200;

            }
            else
            {

                o.IsSuccess = false;
                o.Message = "data not  inserted ";
                o.StatusCode = 500;

            }
            return o;

        }

        public DistrictModelClass update(DistrictModelClass o)
        {

            query = "update DistrictMaster1 set DistrictName= '" + o.DistrictName + "'where DistrictId=" + o.DistrictId + "";
            int resut = db.ExecuteOnlyQuery(query);
            if (resut > 0)
            {

                o.IsSuccess = true;
                o.Message = "data updated suc-cessfully ";
                o.StatusCode = 200;

            }
            else
            {

                o.IsSuccess = false;
                o.Message = "update unsucussfully ";
                o.StatusCode = 500;

            }
            return o;

        }

        public bool delete(int id)
        {

            query = "delete from DistrictMaster1 where DistrictId=" + id + "";
            int resut = db.ExecuteOnlyQuery(query);
            if (resut > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        private List<DistrictModelClass> getAllDetails(DataTable tbl)
        {
            List<DistrictModelClass> li = new List<DistrictModelClass>();
            for (int i = 0; i < tbl.Rows.Count; i++)
            {
                DistrictModelClass tm = new DistrictModelClass();
                
                tm.DistrictName = (string)tbl.Rows[i]["DistrictName"];
                tm.DistrictId = (int)tbl.Rows[i]["DistrictId"];
                tm.IsSuccess = true;
                tm.Message = "Data found Suc-cessfully";
                tm.StatusCode = StatusCodes.Status200OK;
                li.Add(tm);

            }
            return li;
        }
    }

}
