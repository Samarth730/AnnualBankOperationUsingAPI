﻿
using BankOperation.DBLAyer;
using BankOperation.Model;
using System.Data;
using System.Text.RegularExpressions;

namespace BankOperation.BLLayer
{
    public class BranchBLClass
    {

      BankBranchModel obje = new BankBranchModel();
      DatabaseBranch dbl = new DatabaseBranch();
      string sqlQuery = string.Empty;

        public List<BankBranchModel> GetAllDetails()
        {
            List<BankBranchModel> lis = new List<BankBranchModel>();
            sqlQuery = "select * from BranchMaster";
            DataTable ds = dbl.GetDataTable(sqlQuery);
            lis = GetAllBranchDetails(ds);
            return lis;

        }
        public BankBranchModel GetOneDetails(int id)
        {
            BankBranchModel oneOb = new BankBranchModel();
            sqlQuery = "select * from BranchMaster where BranchId =" + id+"";
            DataTable ds = dbl.GetDataTable(sqlQuery);
            oneOb = GetAllBranchDetails(ds).FirstOrDefault();


            if(oneOb != null)
            {
                oneOb.IsSuccess = true;
                oneOb.Message = "sucsuus";
                oneOb.StatusCode = StatusCodes.Status200OK;
            }
            else
            {
                oneOb = new BankBranchModel();
                oneOb.IsSuccess = false;
                oneOb.Message = "data not found";
                oneOb.StatusCode = StatusCodes.Status404NotFound;
            }

            return oneOb;

        }

        public BankBranchModel SaveDetails(BankBranchModel m)
        {
            //#region Validation
            TalukModelClass taluobj = new TalukBLClass().getOne(m.temAdd.tempTALUKID);
            if (taluobj == null)
            {
                m.IsSuccess = false;
                m.Message = $"invalid taluk ID {m.temAdd.tempTALUKID}";
                m.StatusCode = 404;
                return m;
            }
            DistrictModelClass disObj = new DistrictBLClass().getOne(m.temAdd.tempDISTRICTID);
            if (disObj == null)
            {
                m.IsSuccess = false;
                m.Message = $"invalid DistrictId you enterd {m.temAdd.tempDISTRICTID}";
                m.StatusCode = 404;
                return m;
            }
            if (m.temAdd.tempDISTRICTID != taluobj.DistrictId)
            {
                m.IsSuccess = false;
                m.Message = $"Invalid DistrictID {m.temAdd.tempDISTRICTID}";
                m.StatusCode = StatusCodes.Status404NotFound;
                return m;
            }
           


            sqlQuery = "Insert into BranchMaster values ('" + m.BranchName + "','" + m.BA_IFSC + "','" + m.temAdd.temp_place+ "','"+m.temAdd.tempAREA + "','" + m.temAdd.tempSTREET + "'," + m.temAdd.tempPINCODE + "," + m.temAdd.tempTALUKID + "," + m.temAdd.tempDISTRICTID + ",'"+m.City+"','"+m.temAdd.TempLandmark+"',"+m.BANKID+")";
            int result = dbl.ExecuteOnlyQuery(sqlQuery);
            
            if (result > 0)
            {
                m.IsSuccess = true;
                m.Message = "Saved successfully";
                m.StatusCode = 200;
                
            }
            else
            {
                m.IsSuccess = false;
                m.Message = "data not Saved successfully";
                m.StatusCode = 404;
            }
            

            

            return m;





        }



        public BankBranchModel Update(BankBranchModel m)
        {
            //#region Validation
            TalukModelClass taluobj = new TalukBLClass().getOne(m.temAdd.tempTALUKID);
            if (taluobj == null)
            {
                m.IsSuccess = false;
                m.Message = $"invalid taluk ID {m.temAdd.tempTALUKID}";
                m.StatusCode = 404;
                return m;
            }
            DistrictModelClass disObj = new DistrictBLClass().getOne(m.temAdd.tempDISTRICTID);
            if (disObj == null)
            {
                m.IsSuccess = false;
                m.Message = $"invalid DistrictId you enterd {m.temAdd.tempDISTRICTID}";
                m.StatusCode = 404;
                return m;
            }
            if (m.temAdd.tempDISTRICTID != taluobj.DistrictId)
            {
                m.IsSuccess = false;
                m.Message = $"Invalid DistrictID {m.temAdd.tempDISTRICTID}";
                m.StatusCode = StatusCodes.Status404NotFound;
                return m;
            }

            sqlQuery = "update BranchMaster set BranchName= '" + m.BranchName + "',BA_IFSC='" + m.BA_IFSC + "',Place = '"+m.temAdd.temp_place+"',Area='" + m.temAdd.tempAREA+ "',Street='" + m.temAdd.tempSTREET + "',Pincode=" + m.temAdd.tempPINCODE+ ",TalukID=" + m.temAdd.tempTALUKID + ",DistrictID=" + m.temAdd.tempDISTRICTID + ",City='" + m.City + "',LandMark = '"+m.temAdd.TempLandmark+"',BANKID=" + m.BANKID+ " where BranchId=" + m.BranchId + "";
            int result = dbl.ExecuteOnlyQuery(sqlQuery);

            if (result > 0)
            {
                m.IsSuccess = true;
                m.Message = "Update successfully";
                m.StatusCode = 200;

            }
            else
            {
                m.IsSuccess = false;
                m.Message = "data not Updated successfully";
                m.StatusCode = 404;
            }
            return m;


        }

        public bool delette(int  id)
        {
            sqlQuery = "delete from BranchMaster where  BranchId=" + id + "";
            int resuly = dbl.ExecuteOnlyQuery(sqlQuery);
            if(resuly > 0) 
            {
                return true ;
            }
            else
            {
                return false;
            }

        }





        private List<BankBranchModel> GetAllBranchDetails(DataTable tbleone)
        {
            List<BankBranchModel> list = new List<BankBranchModel>();
            for(int i = 0; i < tbleone.Rows.Count;i++)
            {
                BankBranchModel branchOb = new BankBranchModel();
                branchOb.BranchId = (int)tbleone.Rows[i]["BranchId"];
                branchOb.BranchName = (string)tbleone.Rows[i]["BranchName"];
                branchOb.BA_IFSC = (string)tbleone.Rows[i]["BA_IFSC"];
                branchOb.City = (string)tbleone.Rows[i]["City"];
                branchOb.BANKID = (int)tbleone.Rows[i]["BANKID"];

                Adress ad = new Adress();
                {
                    ad.temp_place = (string)tbleone.Rows[i]["Place"];
                    ad.tempAREA = (string)tbleone.Rows[i]["Area"];
                    ad.tempSTREET = (string)tbleone.Rows[i]["Street"];
                    ad.tempPINCODE = (int)tbleone.Rows[i]["Pincode"];
                    ad.tempTALUKID = (int)tbleone.Rows[i]["TalukID"];
                    ad.tempDISTRICTID = (int)tbleone.Rows[i]["DistrictID"];
                    ad.TempLandmark = (string)tbleone.Rows[i]["LandMark"];


                }
                branchOb.IsSuccess = true;
                branchOb.Message = "Sucssusefully fetch data";
                branchOb.StatusCode = 200;

                branchOb.temAdd = ad;
                list.Add(branchOb);



            }
            return list;

        }


    }

    
   
    
}
