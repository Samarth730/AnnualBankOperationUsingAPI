﻿using BankOperation.Model;
using BankOperation.DBLAyer;
using System.Data;
namespace BankOperation.BLLayer
{
    public class TalukBLClass
    {
        TalukModelClass obj = new TalukModelClass();
        DBCustomer db = new DBCustomer();
        string query = string.Empty;

        public List<TalukModelClass> getAll()
        {

            query = "select * from [TalukMaster]";
            DataTable dt = db.GetDataTable(query);
            List<TalukModelClass> li = getAllDetails(dt);
            return li;

        }

        public TalukModelClass getOne(int id)
        {
            query = "select * from [TalukMaster] where Id = "+id+" ";
            DataTable dt = db.GetDataTable(query);
            TalukModelClass li = getAllDetails(dt).FirstOrDefault();
           
            if(li == null)
            {
                li = new TalukModelClass();
                li.IsSuccess = false;
                li.Message = "data is not found ";
                li.StatusCode = 404;
            }
            return li;

        }
        public TalukModelClass insert(TalukModelClass o)
        {

            query = "insert into TalukMaster values ('" + o.TalukName + "'," + o.DistrictId + ")";
            int resut = db.ExecuteOnlyQuery(query);
            if (resut >0)
            {
                
                o.IsSuccess = true;
                o.Message = "data inserted suc-cessfully ";
                o.StatusCode = 200;
               
            }
            else
            {

                o.IsSuccess = false;
                o.Message = "data not  inserted ";
                o.StatusCode = 500;

            }
            return o;

        }

        public TalukModelClass update(TalukModelClass o)
        {

            query = "update TalukMaster set TalukName= '" + o.TalukName + "',DistrictId=" + o.DistrictId + "where Id="+o.Id+"";
            int resut = db.ExecuteOnlyQuery(query);
            if (resut > 0)
            {

                o.IsSuccess = true;
                o.Message = "data updated suc-cessfully ";
                o.StatusCode = 200;

            }
            else
            {

                o.IsSuccess = false;
                o.Message = "update unsucussfully ";
                o.StatusCode = 500;

            }
            return o;

        }

        public bool delete(int id)
        {

            query = "delete from TalukMaster where Id=" + id + "";
            int resut = db.ExecuteOnlyQuery(query);
            if (resut > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        private List<TalukModelClass> getAllDetails(DataTable tbl)
        {
            List<TalukModelClass> li = new List<TalukModelClass>();
            for(int i = 0; i < tbl.Rows.Count; i++)
            {
                TalukModelClass tm = new TalukModelClass();
                tm.Id = (int)tbl.Rows[i]["Id"];
                tm.TalukName = (string)tbl.Rows[i]["TalukName"];
                tm.DistrictId = (int)tbl.Rows[i]["DistrictId"];
                tm.IsSuccess = true;
                tm.Message = "Data found Suc-cessfully";
                tm.StatusCode = StatusCodes.Status200OK;
                li.Add(tm);

            }
            return li;
        }
    }
}
