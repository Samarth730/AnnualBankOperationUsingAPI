﻿using BankOperation.DBLAyer;
using BankOperation.Model;
using System.Data;
using System.Security.Cryptography.Xml;

namespace BankOperation.BLLayer
{
    public class BankBLClass
    {        string sqlQuery = string.Empty;
        DBBankClass db = new DBBankClass();
        BankModelClass m = new BankModelClass();
        Adress ad = new Adress();
        
        public List<BankModelClass> getAllDatailes()
        {
            List<BankModelClass> list =new List<BankModelClass> ();   sqlQuery = "select * from BankMaster";
            DataTable tableob = db.GetDataTable(sqlQuery);
            list = GetCustDetails(tableob);
            return list;
           

        }
        public BankModelClass GetsingleDetails(int Id)
        {
            BankModelClass oneob = new BankModelClass();
            sqlQuery = "select * from BankMaster ste where BANKID = " + Id + " ";
            DataTable dt = db.GetDataTable(sqlQuery);
            oneob = GetCustDetails(dt).FirstOrDefault();
            
            if(oneob!= null )
            {

                oneob.IsSuccess = true;
                oneob.Message = "sucssus";
                oneob.StatusCode = StatusCodes.Status200OK; 
                return oneob;
            }
            else
            {
                oneob = new BankModelClass();
                oneob.IsSuccess = false;
                oneob.Message = "Data is not found";
                oneob.StatusCode = StatusCodes.Status404NotFound;
                return oneob;
            }

        }

        public BankModelClass save(BankModelClass oneob)
        {

             
            sqlQuery = "insert into BankMaster values('" + oneob.BA_NAME + "'," + oneob.TOTALNOOFBRANCH + ")";
            int result = db.ExecuteOnlyQuery(sqlQuery);



            if (result != null)
            {

                oneob.IsSuccess = true;
                oneob.Message = "sucssus";
                oneob.StatusCode = StatusCodes.Status200OK;
                return oneob;
            }
            else
            {
                oneob = new BankModelClass();
                oneob.IsSuccess = false;
                oneob.Message = "Data is not found";
                oneob.StatusCode = StatusCodes.Status404NotFound;
                return oneob;
            }
            return oneob;
        }


        public bool Updatedata(BankModelClass m)
        {
            sqlQuery = "update BankMaster set BA_NAME='" + m.BA_NAME + "',TOTALNOOFBRANCH=" + m.TOTALNOOFBRANCH + " where BankId="+m.BANKID+ "";
            int result = db.ExecuteOnlyQuery(sqlQuery);
            if (result > 0)
                return true;
            else
                return false;

        }
        public bool deletedata( int id)
        {
            sqlQuery = "delete from BankMaster where BANKID =" + id + "";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
                return true;
            else
                return false;
        }


        private List<BankModelClass> GetCustDetails(DataTable tableOb)
        {
           List<BankModelClass> listcustOb = new List<BankModelClass>();
            for(int i=0;i<tableOb.Rows.Count;i++)
            {
                BankModelClass custob = new BankModelClass();
                custob.BANKID = (int)tableOb.Rows[i]["BANKID"];
                custob.BA_NAME = (string)tableOb.Rows[i]["BA_NAME"];
               
                custob.TOTALNOOFBRANCH = (int)tableOb.Rows[i]["TOTALNOOFBRANCH"];


                custob.IsSuccess = true;
                custob.Message = "data fetch sucessfully";
                custob.StatusCode = 200;
               
                listcustOb.Add(custob);

            }
            return listcustOb;

        }



    }
}
